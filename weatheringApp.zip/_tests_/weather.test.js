import React from 'react';
import { render } from '@testing-library/react-native';
import Weather from '../components/weather';

test('Weather Component renders data correctly', () => {
  //mock data to pass into Weather component
  const testProps = {
    weather: 'Clear',
    temperature: 30,
    location: 'Singapore, Southwest',
    feelsLike: 34.5,
    forecast: [],
    area: 'Woodlands',
    onSearch: jest.fn(),
    clearQuery: false,
  };

  const { getByText, debug } = render(<Weather {...testProps} />);

  //debug output to verify component structure
  debug();

  //assewrtions
  expect(getByText('30.0°C')).toBeTruthy();
  expect(getByText('Feels like 34.5°C')).toBeTruthy();

  //check if the location is rendered correctly
  const [country, city] = testProps.location.split(', ');
  expect(getByText(new RegExp(country, 'i'))).toBeTruthy();
  expect(getByText(new RegExp(city, 'i'))).toBeTruthy();
  expect(getByText(new RegExp(testProps.area, 'i'))).toBeTruthy();
});