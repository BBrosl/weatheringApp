import React from 'react';
import { render } from '@testing-library/react-native';
import Forecast from '../components/forecast';

test('Forecast Component renders forecast data correctly', () => {
  //mock forecast data
  const mockForecast = [
    { day: 'Mon', icon: 'weather-sunny', temperature: 30 },
    { day: 'Tue', icon: 'weather-cloudy', temperature: 28 },
    { day: 'Wed', icon: 'weather-rainy', temperature: 25 },
  ];

  //render the Forecast component with mock data
  const { getByText } = render(<Forecast forecast={mockForecast} />);

  //verify that each day of the week is rendered
  mockForecast.forEach(day => {
    expect(getByText(day.day)).toBeTruthy();
    expect(getByText(`${day.temperature}°C`)).toBeTruthy();
  });

});