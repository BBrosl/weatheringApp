import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import Refresh from '../components/refresh';
//testing refresh component
test('Refresh Component triggers onRefresh when pressed', () => {
  const onRefreshMock = jest.fn();

  const { getByTestId } = render(<Refresh onRefresh={onRefreshMock} />);

  //simulate button press
  fireEvent.press(getByTestId('refresh-button'));

  //assert function was called
  expect(onRefreshMock).toHaveBeenCalled();
});