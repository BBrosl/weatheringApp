import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import Search from '../components/search';
//search component test
test('Search Component renders correctly and handles input and search', () => {
  // Mock the onSearch function
  const onSearchMock = jest.fn();
  
  // Render the Search component
  const { getByPlaceholderText, getByTestId, rerender } = render(
    <Search onSearch={onSearchMock} clearQuery={false} />
  );

  //ensure that the TextInput and TouchableOpacity are rendered
  expect(getByPlaceholderText('Search location')).toBeTruthy();
  expect(getByTestId('search-icon')).toBeTruthy();

  //simulate typed text
  fireEvent.changeText(getByPlaceholderText('Search location'), 'Britain');

  //simulate button press
  fireEvent.press(getByTestId('search-icon'));

  //make sure that onSearch was called corretly
  expect(onSearchMock).toHaveBeenCalledWith('Britain');

  //render the component again with clearQuery set to true
  rerender(<Search onSearch={onSearchMock} clearQuery={true} />);

  //ensure the TextInput value is cleared
  expect(getByPlaceholderText('Search location').props.value).toBe('');
});