import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import { Alert } from 'react-native';
import Search from '../components/search';

//mock the API call to OpenWeather's API
const fetchWeatherMock = jest.fn((location) => {
  //simulate valid response locations
  const validLocations = ['New York', 'London', 'Paris'];
  //error is location invalid
  if (!validLocations.includes(location)) {
    return Promise.reject(new Error('Location not found'));
  }
  return Promise.resolve({ data: { location } });
});
//mock the onSearch function to simulate API
test('Search Component handles invalid location from API', async () => {
  const onSearchMock = jest.fn(async (searchQuery) => {
    try {
      await fetchWeatherMock(searchQuery);
    } catch (error) {
      //alert if invalid location
      Alert.alert('Error', 'Location not found. Please enter a valid location.');
    }
  });

  jest.spyOn(Alert, 'alert');

  const { getByPlaceholderText, getByTestId } = render(
    <Search onSearch={onSearchMock} clearQuery={false} />
  );
  //simulate invalid location being keyed in
  fireEvent.changeText(getByPlaceholderText('Search location'), 'abcd123');
  fireEvent.press(getByTestId('search-icon'));

  expect(onSearchMock).toHaveBeenCalledWith('abcd123');
  //wait for the Alert to be triggered from invalid input
  await waitFor(() => {
    expect(Alert.alert).toHaveBeenCalledWith(
      'Error',
      'Location not found. Please enter a valid location.'
    );
  });
});