import React, {useState, useEffect} from 'react';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity, Alert} from 'react-native';
import * as Location from 'expo-location';
import { apiKey } from './keys/weatherAPIKeys';
import axios from 'axios';
import Weather from './components/weather';
import { weatherTheming } from './components/weatherTheme';
import Refresh from './components/refresh';
import countries from 'i18n-iso-countries';
countries.registerLocale(require("i18n-iso-countries/langs/en.json"));

export default function App() {

  const [isLoading, setIsLoading] = useState(true);
  const [temperature, setTemperature] = useState(0);
  const [areaName, setAreaName] = useState(null);
  const [locationName, setLocationName] = useState(null);
  const [feelsLike, setFeelsLike] = useState(null);
  const [weatherCondition, setWeatherCondition] = useState(null);
  const [error, setError] = useState(null);
  const [forecast, setForecast] = useState([]);
  const [clearQuery, setClearQuery] = useState(false);

  ///////////////////////////////////////////////////////////////////
  //*used for testing weather conditions*//
  // const testWeatherConditions = ['Rain', 'Clear', 'Thunderstorm', 'Clouds', 'Snow', 'Drizzle', 'Haze', 'Mist'];
  // const [testIndex, setTestIndex] = useState(0);
  /////////////////////////////////////////////////////////////////

  //fetching weather with lat and lon
  const fetchWeather = async (lat, lon) => {
    try {
      //api call to obtain weather data
      const response = await fetch(
        `http://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&APPID=${apiKey}&units=metric`
      );
  
      const json = await response.json();
      //updating weather info
      setTemperature(json.main.temp);
      setWeatherCondition(json.weather[0].main);
      setAreaName(json.name);
      setFeelsLike(json.main.feels_like);
      
      //api call to get location/country name
      const locationResponse = await axios.get(`http://api.openweathermap.org/geo/1.0/reverse?lat=${lat}&lon=${lon}&appid=${apiKey}`);
      const locationData = locationResponse.data[0];

      //convert two-letter country code to the full name
      const fullCountryName = countries.getName(locationData.country, "en");
      setLocationName(`${fullCountryName}, ${locationData.name}`);
      ////////////////////////////////////////////////
      setIsLoading(false);
    } catch (error) {
      setError('Error retrieving weather conditions');
      setIsLoading(false);
    }
  };
  //function for fetching forecast
  const fetchForecast = async (lat = 25, lon = 25) => {
    try {
      //api call for weather forecast
      const response = await fetch(
        `http://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&APPID=${apiKey}&units=metric`
      );

      const json = await response.json();

      //print the forecast data to check
      //console.log(json.list);

      //processing forecast data to get specific days by filtering by index
      const forecastData = json.list.filter((_, index) => index >= 8).filter((_, index) => index % 8 === 0).slice(0, 3).map((item) => {
        const date = new Date(item.dt * 1000);//convert timestamp to date
        const day = date.toLocaleDateString('en-US', { weekday: 'short' });//get day of week
        const weather = item.weather[0].main;
        const temperature = item.main.temp.toFixed(1);

        return {
          day,
          icon: weatherTheming[weather]?.icon || 'weather-sunny',
          temperature,
        };
      });

      setForecast(forecastData);
    } catch (error) {
      setError('Error retrieving forecast');
      
    }
  };
  //function for user search
  const handleSearch = async (query) => {
    try {
        //api call to get coordinates of search query
        const locationResponse = await axios.get(`http://api.openweathermap.org/geo/1.0/direct?q=${query}&limit=1&appid=${apiKey}`);
        if (locationResponse.data.length === 0) {
            Alert.alert(
              'Error',
              'Location not found',
              [{ text: 'OK', onPress: () => setError(null) }],
              { cancelable: false }
            );
            return;
        }
        const { lat, lon } = locationResponse.data[0];
        await fetchWeather(lat, lon); 
        await fetchForecast(lat, lon);

    } catch (error) {
        //setError('Error retrieving location alert');
        Alert.alert(
          'Error',
          'Error retrieving location data',
          [{ text: 'OK', onPress: () => setError(null) }],
          { cancelable: false }
        );
        return;
        
    }
};
//function for resseting user location
const handleRefresh = async () => {
  try {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      setError('Permission to access location was denied');
      return;
    }

    let location = await Location.getCurrentPositionAsync({});
    fetchWeather(location.coords.latitude, location.coords.longitude);
    fetchForecast(location.coords.latitude, location.coords.longitude);
    //set clearQuery to true to clear the search input
    setClearQuery(true); 
    //reset clearQuery after a short delay
    setTimeout(() => setClearQuery(false), 0);
  } catch (error) {
    setError('Error retrieving current location');
  }
};

  //useeffect hook to featch weather and forecast on load
  useEffect(() => {
    (async () => {
      //request location permissions
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        // setError('Permission to access location denied');
        Alert.alert(
          'Error',
          'Error retrieving location data, please allow location permissions in settings',
          [{ text: 'OK', onPress: () => setError(null) }],
          { cancelable: false });
        setIsLoading(false);
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      fetchWeather(location.coords.latitude, location.coords.longitude);
      fetchForecast(location.coords.latitude, location.coords.longitude);
    })();
  },[]);
  //*for testing*/
  //function to cycle through test weather conditions
  // const cycleWeatherCondition = () => {
  //   setTestIndex((prevIndex) => (prevIndex + 1) % testWeatherConditions.length);
  // };

  // // Use test weather condition instead of actual data
  // const testWeatherCondition = testWeatherConditions[testIndex];

  return (
    <View style={styles.container} >
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingTextStyle}>Fetching Weather</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.scrollViewContent}>
          <Weather
            // weather={testWeatherCondition}
            //passing data into component
            weather={weatherCondition}
            temperature={temperature}
            location={locationName}
            feelsLike={feelsLike}
            forecast={forecast}
            area={areaName}
            onSearch= {handleSearch}
            clearQuery = {clearQuery}
          />
          
          <Refresh onRefresh={handleRefresh} />
        </ScrollView>
      )}
      {error && <Text>{error}</Text>}
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffff',
    
  },

  scrollViewContent: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',      
  },

  loadingTextStyle: {
    fontSize: 20, 
    color: 'black',
  },
});
