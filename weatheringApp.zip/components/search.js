import React, { useState, useEffect } from 'react';
import { View, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
//search component for location search
const Search = ({ onSearch, clearQuery }) => {
  //store user input into state
  const [searchQuery, setSearchQuery] = useState('');

  //for clearing text in search box upon refresh
  useEffect(() => {
    if (clearQuery) {
      setSearchQuery('');
    }
  }, [clearQuery]);

  //handle user search
  const handleSearch = () => {
    onSearch(searchQuery);
  };

  return (
    <View style={styles.searchContainer}>
      <TextInput
        style={styles.searchInput}
        placeholder="Search location"
        value={searchQuery}
        onChangeText={setSearchQuery}
      />
      <TouchableOpacity onPress={handleSearch} style={styles.searchIcon}  testID="search-icon">
        <MaterialCommunityIcons name="magnify" size={28} color="black" />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '90%',
    backgroundColor: 'white',
    borderRadius: 10,
    marginVertical: 10,
  },
  searchInput: {
    width: '85%',
    padding: 3,
  },
});

export default Search;