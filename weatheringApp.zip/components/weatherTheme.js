export const weatherTheming = {
    Rain: {
      background: require('../assets/rain.jpg'),
      overlayColor: 'rgba(0, 0, 0, 0.5)',
      title: 'Raining',
      icon: 'weather-rainy'
    },
    Clear: {
      background: require('../assets/clear.jpg'),
      overlayColor: 'rgba(0, 0, 0, 0.55)',
      title: 'Sunny',
      icon: 'weather-sunny'
    },
    Thunderstorm: {
      background: require('../assets/thunderstorm.jpg'),
      overlayColor: 'rgba(0, 0, 0, 0.6)',
      title: 'Stormy',
      icon: 'weather-lightning'
    },
    Clouds: {
      background: require('../assets/cloudy.jpg'),
      overlayColor: 'rgba(0, 0, 0, 0.48)',
      title: 'Cloudy',
      icon: 'weather-cloudy',
    },

    Snow: {
      background: require('../assets/snow.jpg'),
      overlayColor: 'rgba(0, 0, 0, 0.6)',
      title: 'Snowy',
      icon: 'weather-snowy'
    },
    Drizzle: {
      background: require('../assets/drizzle.jpg'),
      overlayColor: 'rgba(0, 0, 0, 0.5)',
      title: 'Drizzle',
      icon: 'weather-rainy'
    },
    Haze: {
      background: require('../assets/haze.jpg'),
      overlayColor: 'rgba(0, 0, 0, 0.6)',
      title: 'Haze',
      icon: 'weather-hazy'
    },
    Mist: {
      background: require('../assets/mist.jpg'),
      overlayColor: 'rgba(0, 0, 0, 0.65)',
      title: 'Mist',
      icon: 'weather-fog'
    }
  };