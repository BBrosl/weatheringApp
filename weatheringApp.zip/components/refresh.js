import React from 'react';
import { TouchableOpacity, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
//refresh component to reset user location and weather info
const Refresh = ({ onRefresh }) => {
    return (
      //touchableopacity to make icon tappable to trigger function
      <TouchableOpacity onPress={onRefresh} style={styles.refreshIcon} testID="refresh-button">
        <MaterialCommunityIcons name="refresh" size={25} color="white" />
      </TouchableOpacity>
    );
  };
  
const styles = StyleSheet.create({
    refreshIcon: {
      paddingTop: 15,
      borderRadius: 30,
      position: 'absolute',
      top: 40,
      right: 20,
    },
  });
  
export default Refresh;