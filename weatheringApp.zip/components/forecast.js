import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
//forecast component to display upcoming weather
const Forecast = ({ forecast }) => {
    return (
      <View style={styles.container}>
        {forecast.map((day, index) => (
          <View key={index} style={styles.dayContainer}>
            <Text style={styles.dayText}>{day.day}</Text>
            <MaterialCommunityIcons name={day.icon} size={32} color="#fff" />
            <Text style={styles.tempText}>{day.temperature}°C</Text>
          </View>
        ))}
      </View>
    );
  };


const styles = StyleSheet.create({
container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
    //marginVertical: 20
},

dayContainer: {
    alignItems: 'center',
    paddingHorizontal: 15,
},

dayText: {
    color: 'white',
    fontSize: 18,
},

tempText: {
    color: 'white',
    fontSize: 18,
},

});

export default Forecast;