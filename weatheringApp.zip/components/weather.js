import React, {useState} from 'react';
import {View, Text, StyleSheet, ImageBackground, StatusBar, TextInput, TouchableOpacity} from 'react-native';
import {MaterialCommunityIcons} from '@expo/vector-icons';
import { weatherTheming } from '../components/weatherTheme';
import Forecast from '../components/forecast';
import Search from '../components/search';
//weather compoent for displaying weather,location,forecast
const Weather = ({ weather, temperature, location, feelsLike, forecast, area, onSearch, clearQuery }) => {
    //use theme based on current weather condition, deafaulting to clear weather theme if not found
    const condition = weatherTheming[weather] || weatherTheming['Clear'];
    
    const roundedTemperature = (temperature !== null && temperature !== undefined) ? temperature.toFixed(1) : 'N/A';
    const roundedFeelsLike = (feelsLike !== null && feelsLike !== undefined) ? feelsLike.toFixed(1) : 'N/A';

  
    return (
      <ImageBackground source={condition.background} style={styles.imageBackground}>
        <StatusBar barStyle="light-content" translucent={true} backgroundColor="transparent" />
        <View style={[styles.overlay, { backgroundColor: condition.overlayColor }]}>
          {/* Container for displaying weather info, show message if no permissions */}
          <View style={styles.containerForWeather}>
            <Text style={styles.areaText}>{area || 'Unknown Area'}</Text>
            <MaterialCommunityIcons name={condition.icon} size={50} style={styles.iconContainer} />
            {temperature !== null && feelsLike !== null ? (
              <>
                <Text style={styles.temperatureText}>{roundedTemperature}°C</Text>
                <Text style={styles.feelsLikeText}>Feels like {roundedFeelsLike}°C</Text>
              </>
            ) : (
              <Text style={styles.errorText}>Weather data not available</Text>
            )}
          </View>
          {/* Forecast */}
          <View>
            <Forecast forecast={forecast} />
          </View>
          {/* Searchbar and location details */}
          <View style={styles.containerBody}>
            <Search onSearch={onSearch} clearQuery={clearQuery} />
            {/* Location details, if no permissions show message instead */}
            {location ? (
              <>
                <Text style={styles.locationStyleCountry}>{location.split(', ')[0]},</Text>
                <Text style={styles.locationStyleArea}>{location.split(', ')[1]}</Text>
              </>
            ) : (
              <Text style={styles.errorText}>Location data not available, please allow loacation permissions</Text>
            )}
            <Text style={styles.title}>{condition.title}</Text>
          </View>
        
        </View>
      </ImageBackground>
      
    );
  };

const styles = StyleSheet.create({

    containerForWeather: {
       flex: 1, 
       width: '100%', 
       alignItems: 'center',
       justifyContent: 'center',  
       padding: 0,
    },

    areaText: {
      alignItems: 'center',
      justifyContent: 'center',
      color: 'white',
      paddingBottom: 15,
      fontSize: 25,
  },

    iconContainer: {
      color: '#fff',
    },

    temperatureText: {
        color: 'white',
        fontSize: 80,
        fontWeight: 'bold',
        fontFamily: ''
    },

    containerBody: {
        alignItems: 'flex-start',
        justifyContent: 'flex-end',
        flex: 1,
        paddingLeft: 20,
        paddingBottom: 15,
        width: '100%',
    },

    title: {
        fontSize:48,
        color: 'white'
    },

    locationStyleCountry: {
        fontSize: 28,
        color: 'white'
    },

    locationStyleArea: {
      fontSize: 35,
      color: 'white'
    },
    
    feelsLikeText: {
        fontSize: 23,
        color: '#fff'
    },

    imageBackground: {
      flex: 1, 
      width: '100%', 
      alignItems: 'center', 
      justifyContent: 'center',  
    },

    overlay: {
      flex: 1, 
      width: '100%', 
      alignItems: 'center', 
      justifyContent: 'center', 
    },

    errorText: {
      flex: 1,  
      alignItems: 'center', 
      justifyContent: 'center', 
      color: 'white'
    },
});

export default Weather;